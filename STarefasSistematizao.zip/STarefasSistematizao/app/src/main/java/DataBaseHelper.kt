import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Defina o nome e versão do banco
private const val DATABASE_NAME = "tasks.db"
private const val DATABASE_VERSION = 1
private const val TABLE_TASKS = "tasks"
private const val COLUMN_ID = "id"
private const val COLUMN_NAME = "name"
private const val COLUMN_DESCRIPTION = "description"

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase?) {
        // Cria a tabela de tarefas
        val createTable = ("CREATE TABLE $TABLE_TASKS (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_NAME TEXT," +
                "$COLUMN_DESCRIPTION TEXT)")
        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_TASKS")
        onCreate(db)
    }

    // Inserir tarefa (Create)
    fun addTask(name: String, description: String): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_NAME, name)
        values.put(COLUMN_DESCRIPTION, description)
        return db.insert(TABLE_TASKS, null, values)
    }

    // Ler todas as tarefas (Read)
    fun getAllTasks(): MutableList<Task> {
        val list = mutableListOf<Task>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_TASKS", null)
        if (cursor.moveToFirst()) {
            do {
                val task = Task(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION))
                )
                list.add(task)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    // Atualizar tarefa (Update)
    fun updateTask(id: Int, name: String, description: String): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_NAME, name)
        values.put(COLUMN_DESCRIPTION, description)
        return db.update(TABLE_TASKS, values, "$COLUMN_ID=?", arrayOf(id.toString()))
    }

    // Excluir tarefa (Delete)
    fun deleteTask(id: Int): Int {
        val db = this.writableDatabase
        return db.delete(TABLE_TASKS, "$COLUMN_ID=?", arrayOf(id.toString()))
    }
}

data class Task(val id: Int, val name: String, val description: String)
